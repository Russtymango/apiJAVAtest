package org.draftable.api.testing;

import com.draftable.api.client.Comparison;
import com.draftable.api.client.Comparisons;
import com.draftable.api.client.Comparisons.Side;
import com.draftable.api.client.KnownURLs;

import java.io.File;
import java.io.IOException;
import java.util.List;


/**
 * Hello world!
 *
 */
public class App
{
    // Cloud API credentials
    private static final String CloudAccountId = "";
    private static final String CloudAuthToken = "";

    public static void main( String[] args )
    {

        try {
            Test();
        } catch (IOException e) {
            System.out.println( "Exception!" );
            System.out.println( e.getMessage() );

        }

    }

    private static void Test() throws IOException
    {
        System.out.println( "starting!" );

        Comparisons comparisons = new Comparisons(CloudAccountId, CloudAuthToken, KnownURLs.CloudBaseURL);
        List<Comparison> comparisonsList = comparisons.getAllComparisons();
        int sz = comparisonsList.size();
        System.out.println( sz );
		//Need to add your comparison links here, change the current location
        Comparison pdfComparison = comparisons.createComparison(
            Side.create(new File("/home/ochambers/Desktop/share/airbnb-left.pdf"), "pdf"),
            Side.create(new File("/home/ochambers/Desktop/share/airbnb-right.pdf"), "pdf")
        );

        System.out.println(String.format("PDF Comparison created: %s", pdfComparison));
		//Need to add your comparison links here, change the current location
        Comparison txtComparison = comparisons.createComparison(
            Side.create(new File("/home/ochambers/Desktop/share/airbnb-left-txt.txt"), "txt"),
            Side.create(new File("/home/ochambers/Desktop/share/airbnb-right-txt.txt"), "txt")
        );

        System.out.println(String.format("PDF Comparison created: %s", txtComparison));

        System.out.println(String.format("PDF Comparison created: %s", pdfComparison));
		
		//Need to add your comparison links here, change the current location
        Comparison mixComparison = comparisons.createComparison(
            Side.create(new File("/home/ochambers/Desktop/share/airbnb-left.pdf"), "pdf"),
            Side.create(new File("/home/ochambers/Desktop/share/airbnb-right-txt.txt"), "txt")
        );

        System.out.println(String.format("PDF Comparison created: %s", mixComparison));

        comparisonsList = comparisons.getAllComparisons();
        System.out.println( comparisonsList.size() );

        comparisons.close();

    }
}
