# How to avoid a major Java Headache

1. Use Ubuntu (Java is pre-installed)

2. Download a tar.gz of [maven](https://maven.apache.org/download.cgi#) (if not already installed)

3. Unzip it in `/usr/local` and symlink the binary to `/usr/local/bin`:

```sh
cd /usr/local/lib
mv ~/Downloads/apache-maven-3.8.4-bin.tar.gz .
tar xzvf apache-maven-3.8.4-bin.tar.gz
rm xzvf apache-maven-3.8.4-bin.tar.gz
ln -s apache-maven-3.8.4/bin/mvn ../bin
mvn --version
```

4. If testing a change not yet published to Maven Central, pull from [github](https://github.com/draftable/compare-api-java-client)

```sh
git clone https://github.com/draftable/compare-api-java-client.git
cd compare-api-java-client
mvn install
```

5. In `pom.xml` update the <dependencies> node to use the version of the API client that you want to test

6. Build the project and run it!

```sh
mvn clean package exec:java -Dexec.mainClass="org.draftable.api.testing.App"
```

note: when running the second time you can use the `-o` flag to run it offline